/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Application's main file.
 */

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
	return NSApplicationMain(argc, argv);
}
